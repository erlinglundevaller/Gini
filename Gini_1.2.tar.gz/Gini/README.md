# Gini
R functions for calculating the Gini coefficient 
