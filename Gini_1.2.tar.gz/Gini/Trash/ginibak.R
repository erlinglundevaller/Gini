
## in:data med region och lön för individerna. ut:region, reg gini, medellön, antal pers
## För att räkna ut gini för Sörens projekt 2013 borde det gå att använda lisa på singasten som slagits ihop från lisa och ramsink i västerobtten.Rnw
## namnen på denna är: ar, linneid, sun2000niva, inkomst eller kanske bättre att räkna ut de separat  Nej just det, vi behöver även församling, kommun, län.


#' Creating data to test the Gini-function


testdata <- function(){ 
  pid <- rep(1:10, each=2)## test
  ar <- rep(c(1:2), 10)
  reg <- c(3,3,3,1,1,1,2,2,2,2,3,3,3,1,1,1,2,2,2,2)## test
  # unique(reg)
  lön <- c(rnorm(10,50,10),rnorm(10,150,10))## test
  
  data <- as.data.frame(cbind(pid, ar, reg,lön)) ## test ersätts med riktigt data med region och lön 
}

#' @param A data.frame with one column reg (region) and one column lön (pay)
huvud <- function(data = data){ ## gini<-huvud(data)
  data <- data[order(data$reg, data$lön),]  ## order efter region och inom region efter lön 
  
  reg.gini <- as.data.frame(cbind(unique(data$reg), rep(NA, length(unique(data$reg))),rep(NA, length(unique(data$reg))),rep(NA, length(unique(data$reg))), rep(NA, length(unique(data$reg))),rep(NA, length(unique(data$reg))),rep(NA, length(unique(data$reg)))))## Skapar container för regionernas ginis
  names(reg.gini) <- c("reg", "gini", "mean", "quart1", "median", "quart3","antal")
  #lön <- sort(lön)
  for(i in 1:length(reg.gini$reg)){
    lön <- data$lön[data$reg == reg.gini$reg[i]]
    kumul.v <- kumul(vec=lön)
    lön.mean <- rep(mean(lön), length(lön))
    kumul.mean <- kumul(vec=lön.mean)
    reg.gini$gini[i] <- 1-sum(kumul.v)/sum(kumul.mean)
    reg.gini$mean[i] <- mean(lön)
    reg.gini[i, c("quart1", "median", "quart3")] <- quantile(lön, c(0.25, 0.5, 0.75) ) ## Skriver en vektor till resultatmatrisen!!!!
    reg.gini$median[i] <- median(lön)
    reg.gini$antal[i] <- length(lön)
  }  
  reg.gini
}


# vec<-lön
kumul <- function(vec){  ## kumul.v <- kumul(vec=lön)  kumul tar en sorterad vektor och räknar ut kumulativa värden för varje position i vektorn
  kum.vec <-rep(NA,length(vec))
  kum.vec[1] <- vec[1]
  for(i in 2:length(vec)){
    kum.vec[i] <- kum.vec[i-1] + vec[i]
  }
  kum.vec
}

